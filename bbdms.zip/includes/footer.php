<footer>
    <div class="w3ls-footer-grids pt-sm-4 pt-3">
      <div class="container py-xl-5 py-lg-3">
        <div class="row">
          <div class="col-md-4 w3l-footer">
            <h2 class="mb-sm-3 mb-2">
              <a href="index.php" class="text-white font-italic font-weight-bold">
                <span>Blood Bank & </span>Donor Management System 
                <i class="fas fa-syringe ml-2"></i>
              </a>
            </h2>
            <p>Blood donation is a selfless act that can have a significant impact on the health and well-being of individuals in need. Donating blood can help save lives, particularly in emergency situations, where the availability of blood can be the difference between life and death. </p>
          </div>
          <!--<div class="col-md-4 w3l-footer my-md-0 my-4">
            <h3 class="mb-sm-3 mb-2 text-white">Address</h3>
            <ul class="list-unstyled">
              <?php 
$pagetype="contactus";
$sql = "SELECT * from tblcontactusinfo";
$query = $dbh -> prepare($sql);
$query->bindParam(':pagetype',$pagetype,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>
              <li>
                <i class="fas fa-location-arrow float-left"></i>
                <p class="ml-4">
                  <span><?php  echo $result->Address; ?>. </p>
                <div class="clearfix"></div>
              </li>
              <li class="my-3">
                <i class="fas fa-phone float-left"></i>
                <p class="ml-4"><?php  echo $result->ContactNo; ?></p>
                <div class="clearfix"></div>
              </li>
              <li>
                <i class="far fa-envelope-open float-left"></i>
                <a href="mailto:info@example.com" class="ml-3"><?php  echo $result->EmailId; ?></a>
                <div class="clearfix"></div>
              </li>
			<?php } } ?></ul>
          </div>
          <div class="col-md-4 w3l-footer">
            <h3 class="mb-sm-3 mb-2 text-white">Quick Links</h3>
            <div class="nav-w3-l">
              <ul class="list-unstyled">
                <li>
                  <a href="index.php">Home</a>
                </li>
                <li class="mt-2">
                  <a href="about.php">About Us</a>
                </li>
                <li class="mt-2">
                  <a href="contact.php">Contact Us</a>
                </li>
            
              </ul>
            </div>
          </div>
        </div>
        <div class="border-top mt-5 pt-lg-4 pt-3 pb-lg-0 pb-3 text-center">
          <p class="copy-right-grids mt-lg-1">©  Blood Bank Donor Management System
           
          </p>
        </div>
      </div>
    </div>-->
	<div class="Que">
			<h2 align="center">Have A Question</h2>
				<dl>
					<dt><a href="Service-Page.html">Services</a></dt>
					<dt><a href="dogHostel.html">Dog Hostel</a></dt>
					<dt><a href="About-Us.html">About Us</a></dt>
					<dt><a href="Contact.html">Contact Us</a></dt>
				</dl>
		</div>
		<div class="Inf">
			<h2 align="center">Information</h2>
			<dl>
				<dt><div class ="spriteContainer2 loc"></div><pre class="data1">Pet Care(Pvt)Ltd,123,1st Floor,
Dalugama,Kelaniya.</pre></dt>			
				<dt><div class ="spriteContainer2 tell"></div><pre class="data2">Telephone:0112 999999
Fax:0094 112 621 382</pre></dt>
				<dt><div class ="spriteContainer2 mail"></div><pre class="data3" align="center">info@petcare.com</pre></dt>
			</dl>
		</div>
		<div class="visit">
			<h2 align="center">Visit Us</h2>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15841.338990489732!2d79.91592515248428!3d6.969777752797316!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae257f649062ffb%3A0xcbffa7579bd3750!2sKelaniya%2011300!5e0!3m2!1sen!2slk!4v1678833095140!5m2!1sen!2slk" width="300" height="180" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</div>
		<div class="ex2" align="center">
			<p>2023 Pet Care 11600.Designed By Team PETCARE</P>
		</div>
	</div>
  </footer>
  <!-- //footer -->